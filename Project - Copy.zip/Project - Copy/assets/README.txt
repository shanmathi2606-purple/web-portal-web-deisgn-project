Place image files in this folder for an attractive UI.
Suggested free image sources (use these keywords on Unsplash / Pexels):
 - hero.jpg : search "catering spread overhead"
 - logo.png : create a 200x200 logo (flower or plate motif)
 - item1.jpg ... item6.jpg : food item photos matching the menu names

For submission, include at least 6 photos (one per menu item) and a hero image. If you cannot fetch images, use placeholders or create simple graphics.
